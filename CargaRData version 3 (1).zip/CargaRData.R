DFFallecimientos <- read_excel('~/RProyectos/Covid_fallecimientos/Covid_fallecimientos.xlsx',sheet = 'Fallecidos', range = 'A2:RG324')

DF2021 <- read_excel('~/RProyectos/Covid_fallecimientos/Covid_fallecimientos.xlsx',sheet = 'Fallecidos2021', range = 'A1:J235')

ListaDeptos <- (DFFallecimientos %>% filter(is.na(departamento)==FALSE) %>% distinct(departamento) %>% arrange(departamento))$departamento

DatosTranspuestos <- data.frame({t(DFFallecimientos)})

DFGuate <- DatosTranspuestos %>% select(X4)

DFGuateFinal <- data.frame(DFGuate[-c(1:5),])

save(list = ls(),file = '~/RProyectos/Covid_fallecimientos/upd_CovidFallecidos.RData')

