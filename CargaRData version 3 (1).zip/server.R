## app.R ##
library(shiny)
library(shinythemes)
library(shinydashboard)
library(readxl)
library(stringr)
library(dplyr)
library(highcharter)
library(wesanderson)
library(shinycssloaders)
library(tidyr)


shinyServer(function(input, output, session) {
# server <- function(input, output) { 
  
  set.seed(122)
  histdata <- rnorm(500)
  
  output$plot1 <- renderPlot({
    data <- histdata[seq_len(input$slider)]
    hist(data)
  })
  
  output$GrafDeptosCant <- renderHighchart({

    DFAgrupacionDeptos <- data.frame(DFFallecimientos %>%
      group_by(departamento) %>%
      summarise(
        Cantidad=n()
      ) %>%
      mutate(
        Porcentaje = round((Cantidad*100)/sum(Cantidad),2)
      )) %>% 
      arrange(desc(Cantidad))
    
    DFAgrupacionDeptos <- DFAgrupacionDeptos %>% filter(DFAgrupacionDeptos$departamento %in% input$FiltroDepto)
    
    # class(DFAgrupacionDeptos$Cantidad) = "numeric"
    numero <- length(unique(DFAgrupacionDeptos$departamento))
    pal <- wes_palette('Zissou1', numero+1,'continuous')
    
      highchart() %>%
      hc_title(text='Fallecimientos por departamento') %>%
      hc_xAxis(categories=as.list(DFAgrupacionDeptos$departamento)) %>%
      hc_yAxis_multiples(list(title = list(text = ""),min = 0, visible=FALSE,opposite = TRUE),
                         list(title = list(text = ""),min = 0, max=max(DFAgrupacionDeptos$Cantidad),visible = FALSE,opposite = FALSE)) %>% 
      hc_add_series(name = "Cantidad", type='column', colorByPoint=TRUE, color=pal, data = DFAgrupacionDeptos$Cantidad) %>% 
      hc_add_series(name = "Porcentaje", yAxis=1, type='spline', colorByPoint=FALSE, color="#0c47a6", data = DFAgrupacionDeptos$Porcentaje) %>%
      hc_legend(reversed = FALSE) %>% 
      hc_tooltip(crosshairs = TRUE, shared = TRUE, pointFormat = '<span style="color:{point.color}">.</span> {series.name}: <b>{point.y:.2f}</b> <br>') %>% 
      hc_plotOptions(column= list(allowPointSelect = FALSE, dataLabels=list(enable = TRUE)), line = list(dataLabels=list(enable = TRUE, format='{point.y:.2f}%'))) %>% 
        hc_add_theme(hc_theme_elementary())
  })
  
  output$GrafDeptosDia <- renderHighchart({
    
    DFAgrupacionDeptos <- data.frame(DFFallecimientos %>%
     group_by(departamento) %>%
     summarise(
       Cantidad=n()
     ) %>%
     mutate(
       Porcentaje = round((Cantidad*100)/sum(Cantidad),2)
     ))
    
    DFAgrupacionDeptos <- DFAgrupacionDeptos %>% filter(DFAgrupacionDeptos$departamento %in% input$FiltroDepto)
    
    # class(DFAgrupacionDeptos$Cantidad) = "numeric"
      numero <- length(unique(DFAgrupacionDeptos$departamento))
      pal <- wes_palette('Zissou1', numero+1,'continuous')
      
      highchart() %>%
        
        hc_title(text='Fallecimientos por dia') %>%
        hc_xAxis(categories=as.list(DFAgrupacionDeptos$departamento)) %>%
        hc_yAxis_multiples(list(title = list(text = ""),min = 0, visible=TRUE,opposite = TRUE),
                           list(title = list(text = ""),min = 0, max=max(DFAgrupacionDeptos$Cantidad),visible = FALSE,opposite = FALSE)) %>% 
        hc_add_series(name = "Cantidad", type='column', colorByPoint=TRUE, color=pal, data = DFAgrupacionDeptos$Cantidad) %>% 
        hc_add_series(name = "Porcentaje", yAxis=1, type='spline', colorByPoint=FALSE, color="#0c47a6", data = DFAgrupacionDeptos$Porcentaje) %>%
        hc_legend(reversed = FALSE) %>% 
        hc_tooltip(crosshairs = TRUE, shared = TRUE, pointFormat = '<span style="color:{point.color}">.</span> {series.name}: <b>{point.y:.2f}</b> <br>') %>% 
        hc_plotOptions(column= list(allowPointSelect = FALSE, dataLabels=list(enable = TRUE)), line = list(dataLabels=list(enable = TRUE, format='{point.y:.2f}%'))) %>% 
        hc_add_theme(hc_theme_elementary())
  })
  
  output$GrafDeptoGuate <- renderHighchart({
    
    colnames(DFGuateFinal)[colnames(DFGuateFinal)=="DFGuate..c.1.5...."] <- 'Guatemala'
    # DFGuateFinal %>% filter(as.numeric(Guatemala)>0)
    
    class(DFGuateFinal$Guatemala) = "numeric"
    numero <- length(unique(DFGuateFinal$Guatemala))
    pal <- wes_palette('Zissou1', numero+1,'continuous')
    
    tbGuate <- as.data.table(DFGuateFinal)
    rownames(DFGuateFinal)
    
    highchart() %>%
      
      hc_title(text='Fallecimientos Depto Guatemala') %>%
      hc_xAxis(categories=as.list(rownames(DFGuateFinal))) %>%
      hc_yAxis_multiples(list(title = list(text = ""),min = 0, visible=TRUE,opposite = TRUE),
                         list(title = list(text = ""),min = 0, max=max(DFGuateFinal$Cantidad),visible = FALSE,opposite = FALSE)) %>% 
      # hc_add_series(name = "Cantidad", type='column', colorByPoint=TRUE, color=pal, data = DFGuateFinal$Guatemala) %>% 
      hc_add_series(name = "Reportados por dia", yAxis=1, type='spline', colorByPoint=FALSE, color="#0c47a6", data = DFGuateFinal$Guatemala) %>%
      hc_legend(reversed = FALSE) %>% 
      hc_tooltip(crosshairs = TRUE, shared = TRUE, pointFormat = '<span style="color:{point.color}">.</span> {series.name}: <b>{point.y:.2f}</b> <br>') %>% 
      hc_plotOptions(column= list(allowPointSelect = FALSE, dataLabels=list(enable = TRUE)), line = list(dataLabels=list(enable = TRUE, format='{point.y:.2f}%'))) %>% 
      hc_add_theme(hc_theme_elementary())
  })
  
})
# shinyApp(ui, server)
# ArchivoExcel <- paste0('C:-Users-pm02-Documents-RProyectos-Covid_fallecimientos.xlsx')
