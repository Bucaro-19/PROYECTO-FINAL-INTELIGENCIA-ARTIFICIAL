library(shiny)
require(shiny)

ui <- dashboardPage(
  dashboardHeader(title = "Basic dashboard"),
  ## Sidebar content
  dashboardSidebar(
    sidebarMenu(
      menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Widgets", tabName = "widgets", icon = icon("th"))
    )
  ),
  ## Body content
  dashboardBody(
    tabItems(
      # First tab content
      tabItem(tabName = "dashboard",
              fluidRow(column(6,
                              pickerInput(inputId = 'FiltroDepto',
                                          label = 'Departamento',
                                          choices = ListaDeptos,
                                          selected = ListaDeptos,
                                          options = list(
                                            `selected-text-format` = "count > 1",
                                            `count-selected-text` = "{0} filtros seleccionados",
                                            `actions-box` = TRUE,
                                            `deselect-all-text` = "Clear All",
                                            `select-all-text` = "Select All"),
                                            multiple = TRUE))
              ),
              fluidRow(
                box(plotOutput("plot1", height = 250)),
                
                box(
                  title = "Controls",
                  sliderInput("slider", "Number of observations:", 1, 100, 50)
                )
              ),
              fluidRow(tabBox(
                title = '', id = ("tabAgrupaciones"),width = 12,
                tabPanel("Casos por departamento",
                         fluidRow(column(12, withSpinner(highchartOutput("GrafDeptosCant"))))
                ),
                tabPanel("Casos por dia",
                         fluidRow(column(12, withSpinner(highchartOutput("GrafDeptosDia"))))
                ),
                tabPanel("Casos Depto Guatemala",
                         fluidRow(column(12, withSpinner(highchartOutput("GrafDeptoGuate"))))
                )
                
              ))
      ),
      
      # Second tab content
      tabItem(tabName = "widgets",
              h2("Widgets tab content")
      )
    )
  )
)